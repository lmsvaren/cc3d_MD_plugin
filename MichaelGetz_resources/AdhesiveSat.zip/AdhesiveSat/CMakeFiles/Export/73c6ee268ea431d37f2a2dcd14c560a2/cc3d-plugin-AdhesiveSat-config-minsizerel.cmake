#----------------------------------------------------------------
# Generated CMake target import file for configuration "MinSizeRel".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "cc3d::AdhesiveSatShared" for configuration "MinSizeRel"
set_property(TARGET cc3d::AdhesiveSatShared APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(cc3d::AdhesiveSatShared PROPERTIES
  IMPORTED_IMPLIB_MINSIZEREL "C:/ProgramData/miniconda3/envs/cc3d_4_8/Lib/site-packages/cc3d/cpp/CompuCell3DPlugins/CC3DAdhesiveSat.lib"
  IMPORTED_LOCATION_MINSIZEREL "C:/ProgramData/miniconda3/envs/cc3d_4_8/Lib/site-packages/cc3d/cpp/CompuCell3DPlugins/CC3DAdhesiveSat.dll"
  )

list(APPEND _cmake_import_check_targets cc3d::AdhesiveSatShared )
list(APPEND _cmake_import_check_files_for_cc3d::AdhesiveSatShared "C:/ProgramData/miniconda3/envs/cc3d_4_8/Lib/site-packages/cc3d/cpp/CompuCell3DPlugins/CC3DAdhesiveSat.lib" "C:/ProgramData/miniconda3/envs/cc3d_4_8/Lib/site-packages/cc3d/cpp/CompuCell3DPlugins/CC3DAdhesiveSat.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
