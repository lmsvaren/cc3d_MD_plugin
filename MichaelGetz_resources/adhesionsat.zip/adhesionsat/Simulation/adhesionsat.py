
from cc3d import CompuCellSetup
        

from adhesionsatSteppables import adhesionsatSteppable

CompuCellSetup.register_steppable(steppable=adhesionsatSteppable(frequency=1))


CompuCellSetup.run()
